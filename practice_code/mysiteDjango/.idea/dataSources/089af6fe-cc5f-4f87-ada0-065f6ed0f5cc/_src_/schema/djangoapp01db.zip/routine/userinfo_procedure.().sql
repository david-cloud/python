CREATE PROCEDURE userinfo_procedure()
  BEGIN
SET @i=0;
UPDATE app01_userinfo SET `id`=(@i:=@i+1);
ALTER TABLE app01_userinfo AUTO_INCREMENT=0;
END;
